/* config.js — 기능 토글 & 기본 설정 (v37, 1초 갱신) */
window.APP_CONFIG = {
  USE_OLD_UI: true,
  ENABLE_UPBIT_VERCEL_PROXY: true,
  ENABLE_BITHUMB_VERCEL_PROXY: true,
  API_BASE: "https://satoshi-wallet-2025.vercel.app",
  INTERVAL_TICKER_MS: 1000,
  INTERVAL_TOP_MS: 1000
};